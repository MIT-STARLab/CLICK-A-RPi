#
#   Hello World client in Python
#   Connects REQ socket to tcp://localhost:5555
#   Sends "Hello" to server, expects "World" back
#

import zmq
import time

context = zmq.Context()

#  Socket to talk to server
print("Connecting to hello world server…")
socket = context.socket(zmq.REQ)
socket.connect("tcp://localhost:5555")

#  Do 10 requests, waiting each time for a response

starttime = time.time()
count = 100000

for request in range(count):
    # print("Sending request %s …" % request)
    socket.send(b"Hello")

    #  Get the reply.
    message = socket.recv()
    # print("Received reply %s [ %s ]" % (request, message))

print(str(round((time.time() - starttime) * 1000 / count,2)) + " ms per pulse (" + str(count) + " pulses in " + str(round((time.time() - starttime)  ,2)) + "s)")
